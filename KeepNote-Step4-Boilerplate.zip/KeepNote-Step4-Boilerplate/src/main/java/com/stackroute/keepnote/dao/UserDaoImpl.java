package com.stackroute.keepnote.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.exception.UserNotFoundException;
import com.stackroute.keepnote.model.User;

/*
 * This class is implementing the UserDAO interface. This class has to be annotated with 
 * @Repository annotation.
 * @Repository - is an annotation that marks the specific class as a Data Access Object, 
 * thus clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database 
 * 					transaction. The database transaction happens inside the scope of a persistence 
 * 					context.  
 * */
@Repository
@Transactional
public class UserDaoImpl implements UserDAO {

	/*
	 * Autowiring should be implemented for the SessionFactory.(Use
	 * constructor-based autowiring.
	 */
	@Autowired
	SessionFactory sessionFactory;

	public UserDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/*
	 * Create a new user
	 */

	public boolean registerUser(User user) {

		boolean saveFlag = false;
		try {
			sessionFactory.getCurrentSession().save(user);
			saveFlag= true;
		}
		catch (Exception e) {
		}
		return saveFlag;
	}

	/*
	 * Update an existing user
	 */

	public boolean updateUser(User user) {

		try {
			sessionFactory.getCurrentSession().saveOrUpdate(user);
			return true;
		} catch (Exception e) {
		}
		return false;

	}

	/*
	 * Retrieve details of a specific user
	 */
	public User getUserById(String userId) {

		User user = (User) sessionFactory.getCurrentSession().load(User.class, userId);
		return user;
	}

	/*
	 * validate an user
	 */

	public boolean validateUser(String userId, String password) throws UserNotFoundException {
		try {
		
			/*sessionFactory.getCurrentSession().createQuery("select * from User where user_id = '"+userId +"' and user_password = '" + password +"'").executeUpdate();*/
			List<User> userList = sessionFactory.getCurrentSession().
			createCriteria(User.class).
			add(Restrictions.eq("userId", userId)).
			add(Restrictions.eq("userPassword", password)).list();

			if(userList!=null && !userList.isEmpty())
			{
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		throw new UserNotFoundException("User not found");

	}

	/*
	 * Remove an existing user
	 */
	public boolean deleteUser(String userId) {
		try {
			int noRecordDeleted = sessionFactory.getCurrentSession().createQuery("delete from User where user_id ='"+userId +"'").executeUpdate();
			if(noRecordDeleted>0)
			{
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

}
